# 账号授权弹窗

fixtures/authorization_cases.json是本批授权路径，rules/popup_protocol.json是跨源消息协议，app提供商户页与授权页。完成starter/popup_authorization.spec.mjs后，将业务程序放到同级output/src/popup_authorization.spec.mjs，再在本目录运行npm run process。入口覆盖生成场景结果、消息台账、确认请求、页面截图和对账摘要。
