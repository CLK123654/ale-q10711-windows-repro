// 完成Playwright跨源授权弹窗程序，并把交付写到input_data同级output。
throw new Error('TODO:实现授权弹窗协议裁决');
