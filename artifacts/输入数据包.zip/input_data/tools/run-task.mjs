import fs from 'node:fs/promises';
import path from 'node:path';
import { spawnSync } from 'node:child_process';

const inputRoot=process.cwd();
const outputRoot=path.resolve(inputRoot,'..','output');
const businessProgram=path.join(outputRoot,'src','popup_authorization.spec.mjs');
const reportRoot=path.join(outputRoot,'reports');
const evidenceRoot=path.join(outputRoot,'evidence');
const requiredReports=['scenario_results.csv','message_audit.csv','authorization_requests.csv','reconciliation_summary.json'];
const assert=(value,message)=>{if(!value)throw new Error(message)};

async function clean(){await fs.rm(reportRoot,{recursive:true,force:true});await fs.rm(evidenceRoot,{recursive:true,force:true})}
function execute(){return spawnSync(process.execPath,[businessProgram],{cwd:inputRoot,encoding:'utf8',timeout:90000,windowsHide:true,env:{...process.env,PW_CHANNEL:process.env.PW_CHANNEL||'chrome'}})}

try{
  assert(path.basename(inputRoot)==='input_data','请在input_data目录执行npm run process');
  await clean();
  const program=await fs.readFile(businessProgram,'utf8');
  assert(!program.includes('TODO'),'业务程序仍含TODO');
  assert(program.includes("from 'playwright'")||program.includes('from "playwright"')||program.includes('/playwright/index.mjs'),'业务程序必须加载输入包提供的Playwright');
  assert(/chromium\.launch/u.test(program)&&/newContext/u.test(program),'业务程序必须启动浏览器并隔离context');
  assert(/waitForEvent\(['"]page['"]\)/u.test(program)&&/getByRole/u.test(program),'业务程序必须真实打开并操作授权弹窗');
  assert(/message_audit\.csv/u.test(program)&&/authorization_requests\.csv/u.test(program),'业务程序必须导出协议台账和确认请求');
  const cases=JSON.parse(await fs.readFile(path.join(inputRoot,'fixtures','authorization_cases.json'),'utf8'));
  assert(Array.isArray(cases)&&cases.length>0,'案例合同为空');
  const ids=cases.map(item=>item.case_id);
  assert(new Set(ids).size===ids.length,'case_id必须唯一');
  for(const id of ids)assert(!program.includes(id),`业务程序不得按案例ID硬编码:${id}`);
  const protocol=JSON.parse(await fs.readFile(path.join(inputRoot,'rules','popup_protocol.json'),'utf8'));
  assert(typeof protocol.message_type==='string'&&Array.isArray(protocol.provider_modes)&&protocol.provider_modes.length>=5,'弹窗协议合同不完整');
  for(const item of cases)assert(protocol.provider_modes.includes(item.provider_mode),`不支持的provider_mode:${item.provider_mode}`);
  await clean();
  const result=execute();
  assert(result.status===0,`Playwright程序执行失败:${result.stdout}${result.stderr}`);
  for(const name of requiredReports){const stat=await fs.stat(path.join(reportRoot,name));assert(stat.isFile()&&stat.size>0,`缺少报告:${name}`)}
  const screenshots=(await fs.readdir(evidenceRoot)).filter(name=>name.endsWith('.png')).sort();
  assert(screenshots.length===cases.length,'截图数量与案例数不一致');
  const reconciliation=JSON.parse(await fs.readFile(path.join(reportRoot,'reconciliation_summary.json'),'utf8'));
  assert(reconciliation.result==='PASS'&&Object.values(reconciliation.relationships).every(Boolean),'授权弹窗对账未闭合');
  console.log(JSON.stringify({result:'PASS',browser:'Playwright',cases:cases.length,reports:4,screenshots:screenshots.length}));
}catch(error){
  await clean();
  console.error(error instanceof Error?error.message:String(error));
  process.exitCode=1;
}
