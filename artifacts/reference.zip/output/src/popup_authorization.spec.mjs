import fs from 'node:fs/promises';
import path from 'node:path';
import http from 'node:http';
import { chromium } from '../../input_data/node_modules/playwright/index.mjs';

const inputRoot=process.cwd();
const outputRoot=path.resolve(inputRoot,'..','output');
const reportRoot=path.join(outputRoot,'reports');
const evidenceRoot=path.join(outputRoot,'evidence');
const cases=JSON.parse(await fs.readFile(path.join(inputRoot,'fixtures','authorization_cases.json'),'utf8'));
const protocol=JSON.parse(await fs.readFile(path.join(inputRoot,'rules','popup_protocol.json'),'utf8'));
const merchantHtml=await fs.readFile(path.join(inputRoot,'app','merchant.html'),'utf8');
const providerHtml=await fs.readFile(path.join(inputRoot,'app','provider.html'),'utf8');
const assert=(value,message)=>{if(!value)throw new Error(message)};

function csvCell(value){const text=String(value??'');return /[",\n]/u.test(text)?`"${text.replaceAll('"','""')}"`:text}
function toCsv(headers,rows){return `${headers.join(',')}\n${rows.map(row=>headers.map(header=>csvCell(row[header])).join(',')).join('\n')}\n`}
function origin(server){const address=server.address();return `http://127.0.0.1:${address.port}`}
function startServer(handler){
  const server=http.createServer(handler);
  return new Promise((resolve,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',()=>resolve(server))});
}
function closeServer(server){return new Promise(resolve=>server.close(resolve))}
function json(response,status,payload){const body=JSON.stringify(payload);response.writeHead(status,{'content-type':'application/json; charset=utf-8','content-length':Buffer.byteLength(body),'cache-control':'no-store'});response.end(body)}
async function body(request){const chunks=[];for await(const chunk of request)chunks.push(chunk);return Buffer.concat(chunks).toString('utf8')}

assert(Array.isArray(cases)&&cases.length>0,'案例合同为空');
assert(new Set(cases.map(item=>item.case_id)).size===cases.length,'case_id必须唯一');
assert(typeof protocol.message_type==='string'&&protocol.message_type.length>0,'message_type缺失');
assert(Number.isInteger(protocol.authorization_timeout_ms)&&protocol.authorization_timeout_ms>=100,'authorization_timeout_ms无效');
assert(Array.isArray(protocol.provider_modes)&&protocol.provider_modes.length>0,'provider_modes缺失');
for(const item of cases){
  assert(item&&typeof item==='object'&&typeof item.case_id==='string'&&item.case_id.length>0,'案例主键无效');
  assert(['trusted','untrusted'].includes(item.provider_origin_class),'provider_origin_class无效');
  assert(protocol.provider_modes.includes(item.provider_mode),'provider_mode不在合同中');
  assert(typeof item.state==='string'&&item.state.length>0,'state无效');
  assert(item.expected&&typeof item.expected.final_status==='string','案例预期缺失');
}

await fs.rm(reportRoot,{recursive:true,force:true});
await fs.rm(evidenceRoot,{recursive:true,force:true});
await fs.mkdir(reportRoot,{recursive:true});
await fs.mkdir(evidenceRoot,{recursive:true});

const confirmationLog=[];
let confirmationIndex=0;
const merchantServer=await startServer(async(request,response)=>{
  const url=new URL(request.url,'http://127.0.0.1');
  if(request.method==='POST'&&url.pathname===protocol.confirmation_path){
    try{
      const payload=JSON.parse(await body(request));
      confirmationIndex+=1;
      confirmationLog.push({case_id:String(payload.case_id||''),request_index:confirmationIndex,state:String(payload.state||''),authorization_code:String(payload.authorization_code||''),accepted:'true'});
      json(response,200,{accepted:true});
    }catch{json(response,400,{accepted:false})}
    return;
  }
  if(url.pathname==='/merchant.html'){response.writeHead(200,{'content-type':'text/html; charset=utf-8','cache-control':'no-store'});response.end(merchantHtml);return}
  response.writeHead(404);response.end();
});
const trustedServer=await startServer((request,response)=>{const url=new URL(request.url,'http://127.0.0.1');if(url.pathname==='/provider.html'){response.writeHead(200,{'content-type':'text/html; charset=utf-8','cache-control':'no-store'});response.end(providerHtml);return}response.writeHead(404);response.end()});
const untrustedServer=await startServer((request,response)=>{const url=new URL(request.url,'http://127.0.0.1');if(url.pathname==='/provider.html'){response.writeHead(200,{'content-type':'text/html; charset=utf-8','cache-control':'no-store'});response.end(providerHtml);return}response.writeHead(404);response.end()});
const merchantOrigin=origin(merchantServer);
const trustedOrigin=origin(trustedServer);
const untrustedOrigin=origin(untrustedServer);
const launchOptions=process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE?{headless:true,executablePath:process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE}:{headless:true,channel:process.env.PW_CHANNEL||'chrome'};
const browser=await chromium.launch(launchOptions);
const scenarioRows=[];
const messageRows=[];
try{
  for(const item of cases){
    const context=await browser.newContext({viewport:{width:1000,height:720}});
    const page=await context.newPage();
    const providerBase=item.provider_origin_class==='trusted'?trustedOrigin:untrustedOrigin;
    const url=new URL('/merchant.html',merchantOrigin);
    for(const[key,value]of Object.entries({case_id:item.case_id,state:item.state,provider_base:providerBase,trusted_origin:trustedOrigin,mode:item.provider_mode,code:item.authorization_code,timeout_ms:protocol.authorization_timeout_ms,message_type:protocol.message_type,confirmation_path:protocol.confirmation_path}))url.searchParams.set(key,String(value));
    await page.goto(url.toString());
    await page.waitForFunction(()=>window.__ready===true);
    const popupPromise=context.waitForEvent('page');
    await page.getByRole('button',{name:'开始授权'}).click();
    const popup=await popupPromise;
    await popup.waitForLoadState('domcontentloaded').catch(()=>{});
    await page.waitForFunction(()=>window.__terminal===true,null,{timeout:3000});
    const observed=await page.evaluate(()=>({final_status:window.__finalStatus,popup_closed:window.__popupClosed,audit:window.__audit}));
    const caseConfirmations=confirmationLog.filter(row=>row.case_id===item.case_id);
    const acceptedMessages=observed.audit.filter(row=>row.decision==='accepted').length;
    const rejectedMessages=observed.audit.filter(row=>row.decision==='rejected').length;
    const confirmedCode=caseConfirmations[0]?.authorization_code??'';
    const passed=observed.final_status===item.expected.final_status&&observed.popup_closed===item.expected.popup_closed&&observed.audit.length===item.expected.message_count&&acceptedMessages===item.expected.accepted_messages&&rejectedMessages===item.expected.rejected_messages&&caseConfirmations.length===item.expected.confirm_requests&&confirmedCode===item.expected.confirmed_code;
    scenarioRows.push({case_id:item.case_id,provider_origin_class:item.provider_origin_class,provider_mode:item.provider_mode,expected_state:item.state,final_status:observed.final_status,popup_closed:String(observed.popup_closed),message_count:observed.audit.length,accepted_messages:acceptedMessages,rejected_messages:rejectedMessages,confirm_requests:caseConfirmations.length,passed:String(passed)});
    observed.audit.forEach((row,index)=>messageRows.push({case_id:item.case_id,message_index:index+1,origin_class:row.origin_class,source_match:String(row.source_match),message_type:row.message_type,received_state:row.received_state,result:row.result,decision:row.decision,reason:row.reason}));
    await page.screenshot({path:path.join(evidenceRoot,`${item.case_id}.png`),fullPage:true});
    await context.close();
  }
}finally{
  await browser.close();
  await closeServer(merchantServer);
  await closeServer(trustedServer);
  await closeServer(untrustedServer);
}

const measures={
  input_case_count:cases.length,
  completed_case_count:scenarioRows.filter(row=>row.passed==='true').length,
  message_audit_rows:messageRows.length,
  accepted_message_count:messageRows.filter(row=>row.decision==='accepted').length,
  rejected_message_count:messageRows.filter(row=>row.decision==='rejected').length,
  confirmation_request_count:confirmationLog.length,
  authorized_case_count:scenarioRows.filter(row=>row.final_status==='authorized').length,
  declined_case_count:scenarioRows.filter(row=>row.final_status==='declined').length,
  timed_out_case_count:scenarioRows.filter(row=>row.final_status==='timed_out').length,
  user_closed_case_count:scenarioRows.filter(row=>row.final_status==='user_closed').length,
  screenshot_count:(await fs.readdir(evidenceRoot)).filter(name=>name.endsWith('.png')).length
};
const expectedSums=cases.reduce((sum,item)=>({messages:sum.messages+item.expected.message_count,accepted:sum.accepted+item.expected.accepted_messages,rejected:sum.rejected+item.expected.rejected_messages,confirmations:sum.confirmations+item.expected.confirm_requests}),{messages:0,accepted:0,rejected:0,confirmations:0});
const relationships={
  all_cases_complete:measures.completed_case_count===measures.input_case_count,
  message_rows_match_contract:measures.message_audit_rows===expectedSums.messages,
  accepted_messages_match_contract:measures.accepted_message_count===expectedSums.accepted,
  rejected_messages_match_contract:measures.rejected_message_count===expectedSums.rejected,
  confirmations_match_contract:measures.confirmation_request_count===expectedSums.confirmations,
  confirmation_state_matches:confirmationLog.every(row=>cases.some(item=>item.case_id===row.case_id&&item.state===row.state)),
  confirmations_are_unique:new Set(confirmationLog.map(row=>row.case_id)).size===confirmationLog.length,
  rejected_messages_not_confirmed:scenarioRows.filter(row=>row.rejected_messages>0&&row.accepted_messages===0).every(row=>row.confirm_requests===0),
  terminal_status_partition:measures.authorized_case_count+measures.declined_case_count+measures.timed_out_case_count+measures.user_closed_case_count===measures.input_case_count,
  source_window_verified:messageRows.every(row=>row.source_match==='true'),
  evidence_per_case:measures.screenshot_count===measures.input_case_count,
  report_primary_keys_unique:new Set(scenarioRows.map(row=>row.case_id)).size===scenarioRows.length&&new Set(messageRows.map(row=>`${row.case_id}:${row.message_index}`)).size===messageRows.length
};
measures.inconsistency_count=Object.values(relationships).filter(value=>value!==true).length;
const reconciliation={result:measures.inconsistency_count===0?'PASS':'FAIL',measures,relationships};
await fs.writeFile(path.join(reportRoot,'scenario_results.csv'),toCsv(['case_id','provider_origin_class','provider_mode','expected_state','final_status','popup_closed','message_count','accepted_messages','rejected_messages','confirm_requests','passed'],scenarioRows));
await fs.writeFile(path.join(reportRoot,'message_audit.csv'),toCsv(['case_id','message_index','origin_class','source_match','message_type','received_state','result','decision','reason'],messageRows));
await fs.writeFile(path.join(reportRoot,'authorization_requests.csv'),toCsv(['case_id','request_index','state','authorization_code','accepted'],confirmationLog));
await fs.writeFile(path.join(reportRoot,'reconciliation_summary.json'),`${JSON.stringify(reconciliation,null,2)}\n`);
if(reconciliation.result!=='PASS')process.exitCode=2;
